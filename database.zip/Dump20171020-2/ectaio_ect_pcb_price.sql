-- MySQL dump 10.13  Distrib 5.6.22, for osx10.8 (x86_64)
--
-- Host: localhost    Database: ectaio
-- ------------------------------------------------------
-- Server version	5.7.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ect_pcb_price`
--

DROP TABLE IF EXISTS `ect_pcb_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ect_pcb_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `boardLayer` tinyint(4) DEFAULT NULL COMMENT '板子层数 0: 单面, 1: 双面, 2: 四层, 3: 六层, 4: 八层',
  `boardMaterial` tinyint(4) DEFAULT NULL COMMENT '板材 0: FR4, 1: CEM1, 2: FR1, 3: 铝基板',
  `boardThickness` tinyint(4) DEFAULT NULL COMMENT '板厚（mm）0: 0.4, 1: 0.6, 2: 0.8, 3: 1.0, 4: 1.2, 5: 1.6, 6: 2.0, 7: 2.5',
  `aluminumOutThickness` tinyint(4) DEFAULT NULL COMMENT '铜箔厚度 外层（oz）0: 1, 1: 2',
  `aluminumInThickness` tinyint(4) DEFAULT NULL COMMENT '内层（oz）0: 0.5',
  `makeupNum` tinyint(4) DEFAULT NULL COMMENT '拼版款数 n-1: n(10)',
  `surfacing` tinyint(4) DEFAULT NULL COMMENT '表面处理 0: 有铅喷锡, 1: 无铅喷锡, 2: 沉金, 3: OSP, 4: 光板',
  `solderMaskcolor` tinyint(4) DEFAULT NULL COMMENT '阻焊颜色 0: 绿色, 1: 红色, 2: 蓝色, 3: 白色, 4: 黑色, 5: 哑光黑色, 6: 无',
  `charColor` tinyint(4) DEFAULT NULL COMMENT '字符颜色 0: 白色, 1: 黄色, 2: 黑色, 3: 无',
  `minLineSpace` tinyint(4) DEFAULT NULL COMMENT '最小线宽线距 0: 5/5mil以上',
  `minAperture` tinyint(4) DEFAULT NULL COMMENT '最小孔径 0: 0.30mm以上',
  `holeAmount` tinyint(4) DEFAULT NULL COMMENT '孔数 0: 10万孔以下/m², 1: 10-20万孔/m², 2: 20万孔以上/m²',
  `halfHole` tinyint(4) DEFAULT NULL COMMENT '半孔 0: 无, 1: 一边半孔, 2: 二边半孔, 3: 三边半孔, 4: 四边半孔',
  `testMethod` tinyint(4) DEFAULT NULL COMMENT '测试方式 0: 全部飞针测试(样板飞测免费)：光学AOI测试 + 飞针测试，成品直通率100%测试, 1: 抽测免费：成品直通率95%以上测试：全部光学AOI测试 + 飞针测试抽测（如抽测过程中直通率低于95%，此批全部免费飞针测试 ）, 2: 测试架测试：测试免费，测试架工具费为一次性收费，返单免费, 3: 目测：用人工目检，适合单面板及简单的板',
  `urgent` tinyint(4) DEFAULT NULL COMMENT '加急 0: 正常交期, 1: 加急48小时, 2: 加急24小时, 3: 特快加急12小时, 4: 火箭加急8小时',
  `price` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ect_pcb_price`
--

LOCK TABLES `ect_pcb_price` WRITE;
/*!40000 ALTER TABLE `ect_pcb_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `ect_pcb_price` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-20 18:29:11

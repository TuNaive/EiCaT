-- MySQL dump 10.13  Distrib 5.6.22, for osx10.8 (x86_64)
--
-- Host: localhost    Database: ectaio
-- ------------------------------------------------------
-- Server version	5.7.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ect_channel`
--

DROP TABLE IF EXISTS `ect_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ect_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '网站前台频道数据',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父频道ID',
  `title` varchar(45) NOT NULL COMMENT '频道标题',
  `url` varchar(45) NOT NULL COMMENT '频道路径',
  `target` varchar(45) DEFAULT NULL COMMENT '新窗口打开标志',
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序顺序',
  `createAt` datetime NOT NULL COMMENT '数据创建时间',
  `updateAt` datetime NOT NULL COMMENT '数据更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '数据状态(通用) -1:失效 1:生效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='网站前台子频道';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ect_channel`
--

LOCK TABLES `ect_channel` WRITE;
/*!40000 ALTER TABLE `ect_channel` DISABLE KEYS */;
INSERT INTO `ect_channel` VALUES (1,0,'首页','/',NULL,1,'2017-09-11 00:00:00','2017-09-11 00:00:00',1),(2,0,'PCB/PCBA','/pcbsvr',NULL,2,'2017-09-11 00:00:00','2017-09-11 00:00:00',1),(3,0,'公司介绍','/aboutus',NULL,3,'2017-09-11 00:00:00','2017-09-11 00:00:00',1),(4,0,'网站地图','/sitemap',NULL,4,'2017-09-11 00:00:00','2017-09-11 00:00:00',1);
/*!40000 ALTER TABLE `ect_channel` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-20 18:29:12

-- MySQL dump 10.13  Distrib 5.6.22, for osx10.8 (x86_64)
--
-- Host: localhost    Database: ectaio
-- ------------------------------------------------------
-- Server version	5.7.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ect_pcb_order`
--

DROP TABLE IF EXISTS `ect_pcb_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ect_pcb_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '数据id',
  `boardLength` int(11) NOT NULL COMMENT '板子尺寸长（CM）',
  `boardWidth` int(11) NOT NULL COMMENT '板子尺寸宽（CM）',
  `boardAmount` int(11) NOT NULL COMMENT '数量',
  `boardLayer` tinyint(4) NOT NULL COMMENT '板子层数',
  `boardMaterial` tinyint(4) NOT NULL COMMENT '板材',
  `boardThickness` tinyint(4) NOT NULL COMMENT '板厚（mm）',
  `aluminumOutThickness` tinyint(4) NOT NULL COMMENT '铜箔厚度 外层（oz）',
  `aluminumInThickness` tinyint(4) NOT NULL COMMENT '内层（oz）',
  `makeupNum` tinyint(4) NOT NULL COMMENT '拼版款数',
  `surfacing` tinyint(4) NOT NULL COMMENT '表面处理',
  `solderMaskcolor` tinyint(4) NOT NULL COMMENT '阻焊颜色',
  `charColor` tinyint(4) NOT NULL COMMENT '字符颜色',
  `minLineSpace` tinyint(4) NOT NULL COMMENT '最小线宽线距',
  `minAperture` tinyint(4) NOT NULL COMMENT '最小孔径',
  `holeAmount` tinyint(4) NOT NULL COMMENT '孔数',
  `halfHole` tinyint(4) NOT NULL COMMENT '半孔',
  `testMethod` tinyint(4) NOT NULL COMMENT '测试方式',
  `urgent` tinyint(4) NOT NULL COMMENT '加急',
  `comment` text COMMENT '备注',
  `projectFee` float NOT NULL COMMENT '工程费',
  `boardFee` float NOT NULL COMMENT '板费',
  `makeupFee` float NOT NULL COMMENT '拼版费',
  `specialBoardFee` float NOT NULL COMMENT '特殊板费',
  `filmFee` float NOT NULL COMMENT '菲林费',
  `surfaceFee` float NOT NULL COMMENT '表面处理费',
  `testFee` float NOT NULL COMMENT '测试费',
  `solderMaskColorFee` float NOT NULL COMMENT '阻焊颜色费',
  `charColorFee` float NOT NULL COMMENT '字体颜色费',
  `halfHoleFee` float NOT NULL COMMENT '半孔加工费',
  `urgentFee` float NOT NULL COMMENT '加急费',
  `otherFee` float NOT NULL COMMENT '其他',
  `totalFee` float NOT NULL COMMENT '总费',
  `fileUuid` varchar(50) NOT NULL COMMENT 'PCB文件',
  `contact` varchar(20) NOT NULL COMMENT '联系人',
  `mobile` varchar(20) NOT NULL COMMENT '手机号',
  `email` varchar(50) NOT NULL COMMENT '邮箱',
  `addressId` int(11) NOT NULL COMMENT '收货地址id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ect_pcb_order`
--

LOCK TABLES `ect_pcb_order` WRITE;
/*!40000 ALTER TABLE `ect_pcb_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `ect_pcb_order` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-20 18:29:12
